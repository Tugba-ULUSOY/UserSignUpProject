/**
 *
 * @author tugba
 */
public interface IUserCheckService 
{
    boolean checkUser(User user);
            
}
