
import java.util.Scanner;

/**
 *
 * @author tugba
 */
public class SignUpManager // İş servisimiz yani kontrol yaptığımız class
{
    private IUserCheckService iUserCheckService; // dependence olarak verdik.
    //Tüm UserCheckService lerin ortak özelliği IUserCheckService e bağlı olması. Biz ister AgeUserCheckService i ister ComplexUserCheckService i kullanalım
    // istersek de dışarıdan başka bir servisi kullanalım bir sıkıntı çıkmayacak. Bu şekilde soyutlamayı gerçekleştirmiş olduk.
    
    public SignUpManager(IUserCheckService iUserCheckService) //constructor
    {
        this.iUserCheckService = iUserCheckService;
    }
    
    public void signUp(User user)
    {
       if(iUserCheckService.checkUser(user))
       {
           System.out.println("Kullanıcı Kayıt Oldu: " + user.getName());
       }
       else
       {
           System.out.println("Kullanıcı Kayıt Olamadı");
       }           
    }
}
